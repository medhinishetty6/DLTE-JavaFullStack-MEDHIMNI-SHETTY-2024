package employee.client;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {

    }
}
